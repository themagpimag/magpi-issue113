from gpiozero import JamHat
from time import sleep

jamhat = JamHat()

jamhat.lights_1.blink()
sleep(0.5)
jamhat.lights_2.blink()