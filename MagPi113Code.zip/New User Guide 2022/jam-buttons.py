from gpiozero import JamHat

jamhat = JamHat()

jamhat.button_1.when_pressed = jamhat.on
jamhat.button_2.when_pressed = jamhat.off